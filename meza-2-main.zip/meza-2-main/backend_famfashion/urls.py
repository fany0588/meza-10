from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # SOLO UNA inclusión - la raíz apunta a tu app
    path('', include('app_famfashion.urls')),
    
    # Admin en su propia ruta
    path('admin/', admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)